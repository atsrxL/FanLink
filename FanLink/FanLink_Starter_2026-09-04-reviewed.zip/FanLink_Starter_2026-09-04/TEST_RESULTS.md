# FanLink validation results

Generated: 2026-09-04, local-only review

## Host toolchain

```text
Darwin 24.6.0 arm64
Apple clang 17.0.0
cmake 4.3.4
Python 3.14.7
uv 0.9.27
```

Original input archive (preserved unchanged):

```text
FanLink_Starter_2026-09-04.zip
SHA-256 4f2ae680bcf4bd830a244c521d0d0c235db69af5626b87b907131df50fd19af5
```

## Desktop regression

```text
./scripts/run_native_tests.sh
  PASS: 209 checks

Clang AddressSanitizer + UndefinedBehaviorSanitizer native suite
  PASS: 209 checks

python3 tools/fanlink_cli.py --self-test
  PASS: fanlink_cli self-test

PYTHONOPTIMIZE=1 python3 tools/fanlink_cli.py --self-test
  PASS: fanlink_cli self-test

python3 -m py_compile tools/*.py scripts/*.py
  PASS

./tools/run_firmware_syntax_smoke.sh
  PASS: firmware syntax smoke (stub APIs only)

cmake -S . -B build/cmake-final -DCMAKE_BUILD_TYPE=Debug
cmake --build build/cmake-final --parallel
ctest --test-dir build/cmake-final --output-on-failure
  PASS: 1/1 tests
```

The syntax smoke still uses repository API stubs and is not counted as the real
embedded build.

## Real clean PlatformIO builds

Command:

```bash
PLATFORMIO_CORE_DIR=/tmp/fanlink-pio-core-01a06bca \
  uv run --with 'platformio==6.1.19' python3 tools/build_firmware.py \
  --tx --rx 1 --rx 16 \
  --run-id 20260904-jhemcu-lite-betafpv-nano-reviewed
```

Resolved baseline:

```text
PlatformIO Core 6.1.19
Platform: espressif8266 4.2.1
Framework: Arduino ESP8266 Core 3.1.2
Toolchain: xtensa-lx106-elf GCC 10.3.0
RadioLib 7.7.1
```

Results:

```text
fanlink_tx_esp8285     CLEAN + BUILD PASS
fanlink_rx_node01      CLEAN + BUILD PASS
fanlink_rx_node16      CLEAN + BUILD PASS
```

The build hook also succeeded from a previously absent RX environment after
PlatformIO installed a fresh RadioLib 7.7.1 dependency. It verifies the exact
dependency version/source before applying the target regulator selection and
25 ms BUSY/TX_DONE hard limits. RadioLib is compiled with static 64-byte payload
buffers; the port owns its `ArduinoHal`, avoiding the heap-allocating convenience
`Module` constructor.

Published evidence directory:

```text
dist/20260904-jhemcu-lite-betafpv-nano-reviewed/
```

`BUILD_INFO.json` records dependency/source-manifest provenance. `SHA256SUMS`,
per-binary checksum files and the three complete `*.build.log` files provide
read-back verification. Exact sizes and digests are intentionally read from
that directory rather than duplicated here.

## Target-profile evidence

Against ExpressLRS targets commit
`c4bd7b823594c233e673828ab493a2f8319a756a`:

- TX build: JHEMCU 2.4GHz Lite RX hardware repurposed as FanLink TX, LDO;
- RX builds: BETAFPV 2.4GHz Nano RX, RXEN=9, TXEN=10, DC-DC;
- common radio pins: NSS=15, DIO1=4, RST=2, BUSY=5, SCK=14, MISO=12,
  MOSI=13.

This validates build profiles, not the PCB revision of either physical board.

## Source/package gates

```text
make verify
  PASS

./scripts/source_manifest.sh --check
  PASS

reviewed source ZIP unzip -t
  PASS

reviewed source ZIP extracted SOURCE_MANIFEST.sha256
  PASS
```

## Not validated

- No firmware was flashed.
- Physical PCB revisions and original firmware targets were not read back.
- SX1280/SX1281, oscillator, DCDC inductor, TCXO and PA/LNA/RF-switch hardware
  were not inspected or measured.
- No actual RF packet, RSSI, airtime, turnaround, loss or endurance test ran.
- No 25 kHz PWM waveform, GPIO1 ROM boot transient or fail-to-full transition
  was measured on an oscilloscope.
- Tach voltage, pulses per revolution, RPM accuracy and stall behavior were not
  measured on a fan.
- The nominal 10 ms slot has not been accepted against worst-case physical
  timing.
