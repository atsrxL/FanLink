# Changelog

## 0.1.1 — 2026-09-04

Local review and real dependency-build milestone:

- Added target profiles for JHEMCU 2.4GHz Lite RX hardware repurposed as the
  FanLink TX and BETAFPV 2.4GHz Nano as the FanLink RX, derived from pinned
  ExpressLRS target data.
- Added the BETAFPV Nano RXEN/TXEN truth table and per-target LDO/DC-DC
  regulator selection; retained minimum `-18 dBm` bring-up power.
- Corrected RadioLib 7.7.1 integration for project includes, real error codes,
  exact 30-byte fixed packet mode and timeout units without changing protocol v1.
- Added a version/source-checked RadioLib integration hook so JHEMCU remains in
  LDO mode from initial configuration and BUSY/TX_DONE waits are hard-capped at
  25 ms; enabled 64-byte static RadioLib buffers for the 30-byte data path.
- Hardened RX watchdog deadline handling, TX watchdog equality, sequence
  reacquisition, exact duplicate acceptance and failsafe-status latching.
- Reordered ESP8266 PWM output setup to preload the safe level and corrected a
  Tach timestamp race; GPIO16 Tach is now rejected explicitly.
- Expanded native regression coverage from 143 to 209 checks and passed an
  AddressSanitizer/UndefinedBehaviorSanitizer run.
- Added pinned PlatformIO CI plus Python syntax, optimized self-test, firmware
  syntax and source-manifest gates.
- Made local builds clean and transactional, with unique run directories,
  complete logs, provenance and SHA-256 manifests; made source ZIP packaging
  exclude generated artifacts and use a portable read-back-verified checksum.
- Corrected the deterministic loss-ratio simulator and made Python self-tests
  effective under `PYTHONOPTIMIZE=1`.
- Completed clean real-dependency builds for TX, RX Node 01 and RX Node 16 with
  PlatformIO Core 6.1.19, `espressif8266@4.2.1`, Arduino ESP8266 Core 3.1.2 and
  RadioLib 7.7.1.
- No flashing, RF exchange, PWM/Tach measurement, thermal test or PCB-revision
  confirmation is claimed.

## 0.1.0 — 2026-09-04

Initial Codex hand-off starter:

- Created a standalone FanLink application rather than an ExpressLRS fork.
- Added fixed 30-byte Control and 30-byte RPM Reply packets.
- Added CRC-16/CCITT-FALSE and fixed-length binary host serial protocol.
- Added full-state 16-channel downlink and strict poll 1–16 scheduling.
- Added TX host watchdog and RX link watchdog, both failing to full speed.
- Added RX stale-sequence rejection, same-sequence retry support, gap accounting and 16-bit wrap handling.
- Added platform-independent TX/RX controllers and 143 native checks.
- Added ESP8266/ESP8285 fan PWM, Tach and RadioLib SX1280 starter adapters.
- Added PlatformIO environments for TX and RX nodes 01–16.
- Added Python CLI, cluster simulation, build collector, syntax smoke test and hand-off documentation.
- Pinned intended embedded dependencies to `espressif8266@4.2.1` and RadioLib `7.7.1`.
- Set the generic SX1280 chip-power default to `-18 dBm` as a cautious bring-up starting point.
- No embedded dependency build or hardware validation is claimed.
