# FanLink hand-off status

最后更新：2026-09-04  
版本：0.1.1  
状态：本地源码已审查；桌面逻辑和真实嵌入式依赖编译已验证；硬件均未验证，产物不得盲刷。

## 协议与依赖基线

- Air protocol version: 1
- Control packet: 30 bytes
- RPM Reply packet: 30 bytes
- Host serial protocol version: 1
- Slot baseline: 10,000 µs
- Radio backend: RadioLib 7.7.1 SX1280 FLRC, fixed 30-byte adapter
- RF mode: fixed frequency baseline
- PlatformIO Core: `6.1.19`
- PlatformIO platform: `espressif8266@4.2.1`
- Framework: Arduino ESP8266 Core `3.1.2`
- RadioLib: `7.7.1`
- TX profile: JHEMCU 2.4GHz Lite RX hardware repurposed as FanLink TX, LDO
- RX profile: BETAFPV 2.4GHz Nano RX, RXEN=9/TXEN=10, DC-DC
- Target source: ExpressLRS targets `c4bd7b823594c233e673828ab493a2f8319a756a`

## 已执行命令

```text
./scripts/run_native_tests.sh
  PASS: 209 checks

python3 tools/fanlink_cli.py --self-test
  PASS: fanlink_cli self-test

PYTHONOPTIMIZE=1 python3 tools/fanlink_cli.py --self-test
  PASS: fanlink_cli self-test

python3 -m py_compile tools/*.py scripts/*.py
  PASS

./tools/run_firmware_syntax_smoke.sh
  PASS: firmware syntax smoke (stub APIs only)

cmake -S . -B build/cmake -DCMAKE_BUILD_TYPE=Debug
cmake --build build/cmake --parallel
ctest --test-dir build/cmake --output-on-failure
  PASS: 1/1 tests

PlatformIO clean build: fanlink_tx_esp8285, fanlink_rx_node01,
fanlink_rx_node16
  PASS: 3/3
```

## 可复核的构建产物

```text
dist/20260904-jhemcu-lite-betafpv-nano-reviewed/
  BUILD_INFO.json
  SHA256SUMS
  fanlink_tx_esp8285.bin + build log
  fanlink_rx_node01.bin + build log
  fanlink_rx_node16.bin + build log
```

该目录是 manifest 通过后逐环境 clean 编译的证据包，不是硬件验收或刷写授权。

## 已验证硬件

无。

## 已知阻塞项

1. 两块实物的 PCB revision、原固件 target 和刷写/救砖路径尚未核对。
2. target 映射不能证明实板 SX1280/SX1281、TCXO、DCDC 电感、PA/LNA 和 RF switch 真值表。
3. GPIO1 ROM 启动瞬态无法靠固件消除；需外部 gate/base 下拉和示波器验证默认全速。
4. 尚未验证 25 kHz PWM、Tach 电压/RPM、FLRC 空口时长、RF turnaround 和 10 ms 最坏时序。
5. 阻塞射频路径仍须通过 BUSY 卡死注入、长时间运行和独立硬件过温保护验收。
6. 固定频点只适合 bring-up，尚未完成部署和法规评估。

## 下一步唯一动作

确认两块板的正反面高清照片、PCB 丝印/revision 和原固件 target，然后才刷写。
