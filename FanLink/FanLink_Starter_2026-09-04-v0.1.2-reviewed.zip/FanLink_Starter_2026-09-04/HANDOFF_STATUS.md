# FanLink hand-off status

最后更新：2026-09-04  
当前工作树：Unreleased / `0.1.2-dev`  
已归档证据基线：`0.1.1`  
状态：当前源码 native/ASan、面板、CLI、语法/smoke、CTest、source manifest、
`make verify` 和同源码 clean PlatformIO TX/RX01/RX16 门禁均已通过；TX 本地
控制面板已完成部分真实串口及后端退出验收。新固件刷写、RX/RF/PWM/Tach 与热
安全仍未完成。

## 协议与依赖基线

- Air protocol version: 1
- Control packet: 30 bytes
- RPM Reply packet: 30 bytes
- Host serial protocol version: 1
- Slot baseline: 10,000 µs
- Radio backend: RadioLib 7.7.1 SX1280 FLRC, fixed 30-byte adapter
- RF mode: fixed frequency baseline
- PlatformIO Core: `6.1.19`
- PlatformIO platform: `espressif8266@4.2.1`
- Framework: Arduino ESP8266 Core `3.1.2`
- RadioLib: `7.7.1`
- TX profile: JHEMCU 2.4GHz Lite RX hardware repurposed as FanLink TX, LDO
- RX profile: BETAFPV 2.4GHz Nano RX, RXEN=9/TXEN=10, DC-DC
- Target source: ExpressLRS targets `c4bd7b823594c233e673828ab493a2f8319a756a`

## 证据分层

### `0.1.1` 历史基线

```text
native C++                              PASS: 209 checks
native ASan/UBSan                       PASS: 209 checks
Python CLI self-test and -O self-test  PASS
Python compile / firmware stub smoke   PASS
CMake + CTest                           PASS: 1/1
PlatformIO clean TX/RX01/RX16          PASS: 3/3
source/package manifest gates           PASS
```

以上只对应 `dist/20260904-jhemcu-lite-betafpv-nano-reviewed/` 和其
`BUILD_INFO.json` 所绑定的 `0.1.1` 源码，不覆盖当前 Unreleased 变更。

### 当前 Unreleased 控制面板

```text
./scripts/run_native_tests.sh
  PASS: 260 checks

native ASan/UBSan
  PASS: 260 checks

python3 -m unittest discover -s tests -p 'test_fanlink_panel.py' -v
  Ran 17 tests in 3.155 s — OK

CLI self-test, normal and PYTHONOPTIMIZE=1
  PASS

python3 -m py_compile tools/*.py scripts/*.py tests/test_fanlink_panel.py
node --check panel/app.js
  PASS (exit 0)

firmware syntax smoke
  PASS

CMake + CTest build/cmake-20260904-v012
  PASS: 1/1

source manifest check / make verify
  PASS

PlatformIO clean TX/RX01/RX16
  PASS: 3/3
```

完整记录：`docs/evidence/20260904-tx-panel-usb.md`。

当前 clean 固件证据位于
`dist/20260904-v0.1.2-panel-led-rfdiag-release/`，包含完整日志、
`BUILD_INFO.json`、汇总及逐文件 SHA-256。它只证明同源码编译和产物校验，不证明
刷写、应用启动或任何 RF/RX/风扇硬件行为。

真实 TX 串口部分验收：

- 端口 `/dev/cu.usbmodem5C4C0540041`，USB VID:PID `1A86:55D3`；
- POST connect 返回 `connected=true`，后端命令状态为 16 路全 `255`；未抓取
  第一帧 on-wire 串口数据；
- 持续快照显示 `host_failsafe=false`、uptime 3130 s、`next_poll_id=2`，
  rejected/unknown/decode errors 均为 0；
- 浏览器实际页面显示与 API 相同的数据；
- POST disconnect 后面板状态立即清为全 `255`/stale；这只是面板状态，不是 TX
  failsafe 证据；
- 随后独立 CLI 连续显示 `TX=FAILSAFE`，16 节点 duty 均为 `255`，证明 TX 最终
  进入 failsafe；未测量精确 500 ms 边界；
- 后端进程退出时，页面下一轮询锁定全部控件，watchdog 变未知，并将 RPM、实际
  duty、age、miss 清为 `—`；独立 CLI 再次显示 `TX=FAILSAFE` 和全 `255`；
- 16 节点均 stale、miss=255、RPM=0，未建立 RF/RX 链路；
- 未捕获精确 200 ms 串口发送周期；当前 TX 上的旧固件没有新 `ERROR_EVENT`。

## 控制语义

控制面板发送的是开环 `duty[16]` PWM 命令，不是闭环 RPM 目标。`255` 表示释放
外部开漏级并请求全速；RPM 只是 Tach 遥测。在特定风扇完成 PWM/RPM 标定前，
不得把 duty 显示或描述为承诺转速。

## RX 临时刷写观察

在 `0.1.1` 验证批次之后，一个临时 RX 镜像通过 AtomS3 TCP-UART、ESP8266 ROM
no-stub 路径写至 100%。未取得设备 MD5/readback，也没有可观察应用启动。该结果
既不证明镜像损坏，也不构成成功启动；尚不能证明所写镜像包含当前 Unreleased LED。

## 已验证硬件路径

- TX USB 串口枚举、打开、Host 状态快照接收和浏览器显示；
- 面板断开后，由独立 CLI 观察到 TX 最终处于 failsafe、全部 duty 为 255。

未验证任何 RX、RF、PWM、Tach、RPM 或风扇硬件行为。

## 已知阻塞项

1. 当前实机 TX 仍是旧固件；新 clean TX 固件尚未刷写和观察应用启动。
2. TX 第一帧、精确 200 ms 保活和精确 500 ms watchdog 边界没有串口时间线。
3. 新 `ERROR_EVENT` 的错误注入与页面呈现未验收。
4. 后端退出已验收；USB 拔出、串口 I/O 异常和重连仍未做实机故障注入。
5. 两块实物的 PCB revision、原固件 target 和可靠刷写/救砖路径尚未完整核对。
6. 16 节点全部 stale；RF airtime/turnaround、RX LED、25 kHz PWM、Tach/RPM、
   GPIO1 ROM 瞬态、BUSY 卡死和耐久/热安全均未验证。
7. 固定频点只适合 bring-up，尚未完成部署和法规评估。

## 下一步唯一动作

保持风扇断开，让 JHEMCU TX 进入 ESP8266 ROM BOOT，刷入
`dist/20260904-v0.1.2-panel-led-rfdiag-release/fanlink_tx_esp8285.bin`；重启后先
验证 Host 状态和一条新 `ERROR_EVENT`，再单独推进精确时序与 RF/RX。
