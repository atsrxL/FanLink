# Changelog

## Unreleased — 2026-09-04

- Added a loopback-only TX browser control panel with strict 16-channel input,
  safe `255` defaults, 200 ms full-state refresh, serial status/diagnostic
  parsing, demo mode and explicit disconnect behavior. Its duty controls are
  open-loop PWM commands, not closed-loop RPM targets.
- Passed 17 offline control-panel tests, native and ASan/UBSan suites at 260
  checks each, CLI self-tests in normal and optimized modes, Python/JavaScript
  syntax, firmware stub smoke and CMake/CTest 1/1,
  then connected the panel to a physical TX at `/dev/cu.usbmodem5C4C0540041`
  (USB `1A86:55D3`). Live snapshots and the browser agreed; disconnect reset the
  panel state safely, and a separate CLI subsequently showed persistent TX
  failsafe with all duties at 255.
- Exact 200 ms serial timing, the exact 500 ms watchdog boundary, new
  `ERROR_EVENT` diagnostics and all physical RX/RF/PWM/RPM behavior remain
  unverified. The attached TX carried older firmware without the new diagnostic.
- Verified that terminating the connected backend makes the browser lock all
  controls on its next poll and clear watchdog/RPM/applied-duty fields to unknown;
  an independent CLI again observed TX failsafe and all duties at 255. Evidence:
  `docs/evidence/20260904-tx-panel-usb.md`.
- Added a non-blocking BETAFPV Nano GPIO16 status LED. Search/link-failsafe uses
  two 100 ms flashes followed by 500 ms off; a fresh RX-accepted FanLink
  downlink keeps the LED continuously on.
- Added compile-time LED pin/conflict checks and native boundary tests for the
  complete 800 ms pattern without changing either FanLink wire protocol.
- Added bounded TX `ERROR_EVENT` diagnostics that distinguish radio init,
  transmit, receive timeout, receive CRC/I/O, invalid application replies and
  accepted replies, with saturating counters and no air-protocol change.
- Kept the latest actionable TX/RX driver errors across later successful slots,
  split the last TX/RX raw codes, and bounded the worst-case compact diagnostic
  text to one 128-byte Host frame so a control panel cannot display a silently
  cleared or truncated fault.
- Replaced the shared `-18 dBm` commercial-board setting with target-specific
  build values: JHEMCU Lite `+13 dBm` and BETAFPV Nano PA input `-10 dBm`;
  retained `-18 dBm` only as the generic unknown-board fallback.
- Made the clean firmware collector install each environment's pinned packages
  before invoking `pio run -t clean`, so a new `.pio` tree cannot fail merely
  because the strict RadioLib pre-build hook runs before dependency discovery.
- Kept the `0.1.1` 209-check and three-target clean build as a historical evidence
  baseline, then regenerated and checked the current source manifest, passed
  `make verify`, and completed a separate current-source clean PlatformIO build
  for TX/RX01/RX16 with logs, provenance and reread-verified SHA-256 files in
  `dist/20260904-v0.1.2-panel-led-rfdiag-reviewed/`.
- The new binaries are compilation artifacts only: they have not yet been flashed
  or accepted through application boot, RF, LED, PWM, Tach/RPM, fan or thermal
  behavior.
- Recorded that a temporary RX image was subsequently written to 100% through
  ESP8266 ROM no-stub mode. Device MD5/readback and observable application boot
  were not obtained, so neither that image nor current Unreleased hardware is
  claimed as accepted.

## 0.1.1 — 2026-09-04

Local review and real dependency-build milestone:

- Added target profiles for JHEMCU 2.4GHz Lite RX hardware repurposed as the
  FanLink TX and BETAFPV 2.4GHz Nano as the FanLink RX, derived from pinned
  ExpressLRS target data.
- Added the BETAFPV Nano RXEN/TXEN truth table and per-target LDO/DC-DC
  regulator selection; retained minimum `-18 dBm` bring-up power.
- Corrected RadioLib 7.7.1 integration for project includes, real error codes,
  exact 30-byte fixed packet mode and timeout units without changing protocol v1.
- Added a version/source-checked RadioLib integration hook so JHEMCU remains in
  LDO mode from initial configuration and BUSY/TX_DONE waits are hard-capped at
  25 ms; enabled 64-byte static RadioLib buffers for the 30-byte data path.
- Hardened RX watchdog deadline handling, TX watchdog equality, sequence
  reacquisition, exact duplicate acceptance and failsafe-status latching.
- Reordered ESP8266 PWM output setup to preload the safe level and corrected a
  Tach timestamp race; GPIO16 Tach is now rejected explicitly.
- Expanded native regression coverage from 143 to 209 checks and passed an
  AddressSanitizer/UndefinedBehaviorSanitizer run.
- Added pinned PlatformIO CI plus Python syntax, optimized self-test, firmware
  syntax and source-manifest gates.
- Made local builds clean and transactional, with unique run directories,
  complete logs, provenance and SHA-256 manifests; made source ZIP packaging
  exclude generated artifacts and use a portable read-back-verified checksum.
- Corrected the deterministic loss-ratio simulator and made Python self-tests
  effective under `PYTHONOPTIMIZE=1`.
- Completed clean real-dependency builds for TX, RX Node 01 and RX Node 16 with
  PlatformIO Core 6.1.19, `espressif8266@4.2.1`, Arduino ESP8266 Core 3.1.2 and
  RadioLib 7.7.1.
- No flashing, RF exchange, PWM/Tach measurement, thermal test or PCB-revision
  confirmation is claimed.

## 0.1.0 — 2026-09-04

Initial Codex hand-off starter:

- Created a standalone FanLink application rather than an ExpressLRS fork.
- Added fixed 30-byte Control and 30-byte RPM Reply packets.
- Added CRC-16/CCITT-FALSE and fixed-length binary host serial protocol.
- Added full-state 16-channel downlink and strict poll 1–16 scheduling.
- Added TX host watchdog and RX link watchdog, both failing to full speed.
- Added RX stale-sequence rejection, same-sequence retry support, gap accounting and 16-bit wrap handling.
- Added platform-independent TX/RX controllers and 143 native checks.
- Added ESP8266/ESP8285 fan PWM, Tach and RadioLib SX1280 starter adapters.
- Added PlatformIO environments for TX and RX nodes 01–16.
- Added Python CLI, cluster simulation, build collector, syntax smoke test and hand-off documentation.
- Pinned intended embedded dependencies to `espressif8266@4.2.1` and RadioLib `7.7.1`.
- Set the generic SX1280 chip-power default to `-18 dBm` as a cautious bring-up starting point.
- No embedded dependency build or hardware validation is claimed.
