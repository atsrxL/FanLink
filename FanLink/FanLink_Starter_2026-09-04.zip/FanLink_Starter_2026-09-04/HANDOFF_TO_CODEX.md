# FanLink → Codex Hand-off

交接日期：2026-09-04  
基线版本：0.1.0  
交接性质：可继续开发的基础源码，不是可直接刷写的成品固件。

## 1. Owner intent

用户要的是一个极简专用无线风扇总线，而不是删减到难以维护的完整 ELRS fork：

```text
TX 每个时隙广播 duty[1..16]，并循环 poll_id=1..16
RX X 只应用 duty[X] 的 25 kHz PWM
RX X 只有在 poll_id=X 时回传 RPM
所有异常默认全速
```

不要恢复 ExpressLRS 的 Lua、MSP、WebUI、Wi-Fi、通用 RC、通用遥测、模型匹配、动态功率等功能。

## 2. 当前源码架构

### 2.1 可移植公共层

`include/fanlink/`、`src/common/`、`src/app/`：

- CRC-16/CCITT-FALSE；
- 固定 30 字节 Control/RPM 包编解码；
- 固定帧头二进制 Host 协议；
- TX 16 通道、poll、host watchdog、遥测表；
- RX 通道选择、序号排序、link watchdog、堵转状态、按需回复；
- `IRadioPort`、`IClock`、`IFanOutput`、`ITachometer` 平台边界。

公共层不包含 Arduino、SPI、RadioLib 或具体 GPIO，可直接在桌面测试。

### 2.2 ESP8266 平台层

`lib/fanlink_platform_esp8266/src/fanlink/platform/esp8266/`：

- `fan_output.*`：调用 ESP8266 Arduino Core PWM API，逻辑层固定 25 kHz，处理外部开漏级反相；
- `tachometer.*`：下降沿 ISR 只记录周期，主循环计算 RPM；
- `radiolib_sx1280_port.*`：RadioLib 7.7.1、SX1280 FLRC、固定频点、固定 30 字节收发；
- `arduino_clock.hpp`：时钟接口。

### 2.3 Arduino 入口

- `src/main_tx.cpp`：Host 帧解析、TX 时隙循环、状态快照；
- `src/main_rx.cpp`：单节点 RX，无 Serial 初始化，避免占用 GPIO1/3。

### 2.4 工具与测试

- `tests/native_tests.cpp`：公共协议和状态机测试；
- `tests/stubs/`：只供平台代码语法 smoke；
- `tools/fanlink_cli.py`：Host 二进制协议参考实现；
- `tools/build_firmware.py`：PlatformIO 构建/收集 `.bin`；
- `tools/simulate_cluster.py`：16 节点轮询计数模型；
- `tools/network_id.py`：从短语生成可重复 network ID，非安全机制。

## 3. 交付前已实际执行的检查

```text
./scripts/run_native_tests.sh
  -> PASS: 143 checks

python3 tools/fanlink_cli.py --self-test
  -> PASS: fanlink_cli self-test

python3 -m py_compile tools/*.py
  -> PASS

./tools/run_firmware_syntax_smoke.sh
  -> PASS: firmware syntax smoke (stub APIs only)

cmake -S . -B build/cmake -DCMAKE_BUILD_TYPE=Debug
cmake --build build/cmake --parallel
ctest --test-dir build/cmake --output-on-failure
  -> PASS: 1/1
```

测试覆盖了：

- CRC 标准向量；
- Control/RPM round-trip 和 CRC 拒绝；
- 两种空口包固定 30 字节；
- Host parser 重同步；
- poll 1→16；
- Host failsafe；
- 回包 node/sequence 匹配；
- RX 通道选择；
- 只在本节点 poll 时回包；
- RX link failsafe；
- FORCE_FULL_SPEED；
- sequence gap；
- 明显旧序号拒绝；
- 相同序号重试；
- 16 位序号回绕；
- 错 network ID 和坏 CRC 拒绝。

## 4. 明确没有验证的项目

- 未成功运行真实 PlatformIO 依赖构建；交付环境没有 `pio` 和可用联网依赖解析；
- 未在真实 ESP8285/ESP8266 Core 与 RadioLib 头文件上编译链接；
- 未确认任何商业 ELRS 板的准确引脚；
- 未验证 SX1280 SPI、BUSY、DIO1、TCXO；
- 未实现或验证具体板型的 PA/LNA/RF switch 真值表；
- 未发送实际射频包；
- 未测量 10 ms 时隙是否有足够余量；
- 未用示波器验证 25 kHz PWM；
- 未测量 GPIO1 启动输出；
- 未测 Tach 电压或 RPM 精度；
- 未做多节点碰撞、长时间或法规测试。

禁止把 stub smoke 或桌面测试描述为“可直接刷写”。

## 5. 关键设计决定

1. **独立 FanLink 协议，不复制 ELRS 源码。**
2. **每包完整 duty[16]。** 下行无需确认或增量恢复。
3. **显式单节点 poll。** 同一时隙只有一个合法回复者。
4. **上下行都固定 30 字节。** 简化所有节点的固定长度接收。
5. **二进制 Host 协议。** CRSF 暂不实现；将来只能作为适配器。
6. **固定频点优先。** 先解决板级 RF 闭环，再单独设计 rendezvous/FHSS。
7. **异常全速。** 软件 watchdog 与开漏硬件默认状态共同保证。
8. **阻塞 RadioLib 作为 bring-up 基线。** 只有实测证明 10 ms 不够才改异步。

完整理由见 `docs/DECISIONS.md`。

## 6. 第一优先级：先让真实嵌入式构建通过

依次执行：

```bash
pio run -e fanlink_tx_esp8285
pio run -e fanlink_rx_node01
pio run -e fanlink_rx_node16
```

处理真实 API 差异时：

- 保持 `IRadioPort` 公共接口不变；
- 不改变 30 字节 wire format；
- 不删除应用 CRC；
- 不用“编译方便”为理由引入完整 ELRS；
- 将每个修复写入 `CHANGELOG.md` 和 `HANDOFF_STATUS.md`。

重点核对 RadioLib 7.7.1 的：

- `Module` SPI 构造函数；
- `beginFLRC` 参数类型；
- `setSyncWord`；
- `setCRC`；
- `receive(data, len, timeout)` 的 timeout 单位和固定长度行为；
- `setRfSwitchPins` 是否足以覆盖目标板前端。

## 7. 第二优先级：建立准确硬件 target

用户提供实际板型后，为 TX 和 RX 分别建立 target 配置，不能只修改一个“万能引脚表”。至少核对：

```text
板名与 PCB revision
原 ELRS target / hardware.json / 原理图来源
MCU、flash、晶振
SX1280/SX1281 型号
NSS / DIO1 / RESET / BUSY / SPI
TCXO 控制
RXEN / TXEN / PA enable / LNA enable
天线 switch 真值表
最大安全发射功率
GPIO1/GPIO3 与 USB-UART/板载器件
可恢复刷写方式
```

默认 `15/4/2/5` 只是常见裸模块示例，不能视为任何商品板结论。

## 8. 第三优先级：单节点 bring-up

推荐顺序：

1. 不接风扇，最小功率验证 TX/RX SPI 和固定包收发；
2. 只做 TX→RX，暂时禁止 RX 发射；
3. 用调试脚/逻辑分析仪证明 `sequence` 和本节点 duty；
4. 接开漏控制级，用示波器测 25 kHz；
5. 验证 0/1/64/128/192/254/255；
6. 验证 TX 掉电、RX 复位、坏 CRC 均回全速；
7. 测 Tach 高电平后才连接 GPIO；
8. 验证 RPM；
9. 开启一个 RX Reply，测实际 turnaround；
10. 调整 `replyDelayUs`、`replyTimeoutMs` 和 `slotPeriodUs`。

## 9. 多节点前必须解决的事项

- 每个节点 ID 唯一且有物理标签；
- 确认未被 poll 的 RX 不发射；
- 缺失节点只增加 missed poll，不延迟下一时隙；
- 轮询周期、状态快照和 Host 串口输出不会破坏时隙；
- 重复 node ID 的碰撞现象被记录；
- 至少 4 节点通过后再扩展到 16。

## 10. 安全关键事项

- 标准风扇 Pin 3 是 Tach，Pin 4 是 PWM；
- PWM 必须通过外部开漏/开集电极级；
- Tach 必须确认是 3.3 V 安全电平；
- GPIO1 在 ESP8266 ROM 启动阶段可能输出串口信息，必须测量；
- 外部晶体管 gate/base 必须有安全默认下拉，使 MCU 复位时释放风扇 PWM 线；
- 无线控制不能替代设备自身的过温保护和关机机制。

## 11. 不要在 P0 做的工作

- Wi-Fi/WebUI；
- Lua/MSP/标准 ELRS兼容；
- 完整 CRSF；
- 动态节点发现；
- OTA；
- 动态功率/速率；
- 通用传感器框架；
- 代码风格大重构；
- 在固定频点闭环前实现 FHSS。

## 12. 下一次回交用户必须包含

- 精确支持的 TX/RX 板型与 revision；
- 完整可复现构建日志；
- 固件 `.bin` 与 SHA-256；
- 最终引脚/RF 前端真值表；
- 接线图与器件值；
- 25 kHz 示波器测量；
- Tach 电压与 RPM 对比表；
- RF 时隙/turnaround 测量；
- failsafe 故障注入结果；
- 节点数量、运行时长、丢包/复位统计；
- 所有仍未验证和明确不支持的事项。

接手提示词见仓库根目录 `codex_prompt.txt`。
