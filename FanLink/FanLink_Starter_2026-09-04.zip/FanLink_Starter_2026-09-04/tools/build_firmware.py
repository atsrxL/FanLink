#!/usr/bin/env python3
"""Build selected PlatformIO environments and collect firmware binaries."""

from __future__ import annotations

import argparse
import hashlib
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "dist"


def environment_for_rx(node: int) -> str:
    return f"fanlink_rx_node{node:02d}"


def build_environment(name: str) -> Path:
    pio = shutil.which("pio") or shutil.which("platformio")
    if not pio:
        raise RuntimeError("PlatformIO CLI not found")
    subprocess.run([pio, "run", "-e", name], cwd=ROOT, check=True)
    source = ROOT / ".pio" / "build" / name / "firmware.bin"
    if not source.is_file():
        raise RuntimeError(f"build succeeded but {source} was not produced")
    DIST.mkdir(exist_ok=True)
    destination = DIST / f"{name}.bin"
    shutil.copy2(source, destination)
    digest = hashlib.sha256(destination.read_bytes()).hexdigest()
    (DIST / f"{name}.bin.sha256").write_text(
        f"{digest}  {destination.name}\n", encoding="utf-8"
    )
    return destination


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tx", action="store_true", help="build the TX image")
    parser.add_argument(
        "--rx",
        type=int,
        action="append",
        choices=range(1, 17),
        metavar="NODE",
        help="build one RX node; may be repeated",
    )
    parser.add_argument("--all-rx", action="store_true", help="build RX nodes 1..16")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    environments: list[str] = []
    if args.tx:
        environments.append("fanlink_tx_esp8285")
    nodes = list(range(1, 17)) if args.all_rx else (args.rx or [])
    environments.extend(environment_for_rx(node) for node in nodes)
    if not environments:
        print("Nothing selected; use --tx, --rx N, or --all-rx", file=sys.stderr)
        return 2
    try:
        for environment in environments:
            output = build_environment(environment)
            print(f"built: {output.relative_to(ROOT)}")
    except (RuntimeError, subprocess.CalledProcessError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
