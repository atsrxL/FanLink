# FanLink hand-off status

最后更新：2026-09-04  
版本：0.1.0  
状态：基础源码已打包；桌面逻辑已验证；真实嵌入式构建和硬件均未验证。

## 协议与依赖基线

- Air protocol version: 1
- Control packet: 30 bytes
- RPM Reply packet: 30 bytes
- Host serial protocol version: 1
- Slot baseline: 10,000 µs
- Radio backend: RadioLib SX1280 FLRC, blocking starter adapter
- RF mode: fixed frequency baseline
- Intended PlatformIO platform: `espressif8266@4.2.1`
- Intended RadioLib version: `7.7.1`

## 已执行命令

```text
./scripts/run_native_tests.sh
  PASS: 143 checks

python3 tools/fanlink_cli.py --self-test
  PASS: fanlink_cli self-test

python3 -m py_compile tools/*.py
  PASS

./tools/run_firmware_syntax_smoke.sh
  PASS: firmware syntax smoke (stub APIs only)

cmake -S . -B build/cmake -DCMAKE_BUILD_TYPE=Debug
cmake --build build/cmake --parallel
ctest --test-dir build/cmake --output-on-failure
  PASS: 1/1 tests
```

## 未执行/未通过的构建

```text
pio run -e fanlink_tx_esp8285       NOT RUN successfully
pio run -e fanlink_rx_node01        NOT RUN successfully
pio run -e fanlink_rx_node16        NOT RUN successfully
```

原因：交付环境没有可用 PlatformIO CLI/依赖缓存，联网安装不可用。不能由此判断真实依赖是否可编译。

## 已验证硬件

无。

## 已知阻塞项

1. 需要准确 TX/RX 型号、PCB revision 或原 ELRS target。
2. 需要确认 SX1280 SPI、DIO1、BUSY、RESET 和 TCXO。
3. 需要 PA/LNA/RF switch/天线开关真值表。
4. 需要验证 RadioLib 7.7.1 与固定 30 字节收发的真实编译/API。
5. 需要示波器验证 25 kHz PWM 和 GPIO1 启动瞬态。
6. 需要测量 Tach 电压并验证 RPM。
7. 需要测量 10 ms 时隙与 turnaround。
8. 固定频点只适合 bring-up，尚未完成部署和法规评估。

## 下一位接手者第一条命令

```bash
./scripts/run_native_tests.sh
```

随后立即运行真实 PlatformIO TX/RX 构建，先修复具体编译问题，不扩展功能。
