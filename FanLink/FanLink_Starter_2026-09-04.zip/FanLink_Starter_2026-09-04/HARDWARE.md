# FanLink 硬件与接线

## 1. 默认目标不是最终板型定义

本包把“常见 ESP8285 + SX1280 接收机”作为起始目标，默认示例：

| 功能 | 默认 GPIO |
|---|---:|
| SX1280 NSS | 15 |
| SX1280 DIO1 | 4 |
| SX1280 RST | 2 |
| SX1280 BUSY | 5 |
| SPI SCK | 14 |
| SPI MISO | 12 |
| SPI MOSI | 13 |
| 风扇 PWM 逻辑输出 | 1（原 UART TX） |
| Tach 输入 | 3（原 UART RX） |
| RF RXEN/TXEN | 未配置 |

这些值只能用于代码骨架。烧写前必须从具体 ELRS target 的硬件定义或原理图核对。

源码默认 SX1280 芯片输出设置为 `-18 dBm`，只作为最低功率 bring-up 起点；外部 PA 的实际输出与启用逻辑仍必须按板型测量。

## 2. 标准四线 PC 风扇

常见四针定义：

| 风扇 Pin | 功能 |
|---:|---|
| 1 | GND |
| 2 | +12 V |
| 3 | Tach / Sense 输出 |
| 4 | PWM Control 输入 |

本项目：

- RX PWM GPIO 经外部开漏/开集电极级接风扇 Pin 4；
- 风扇 Pin 3 经确认过的 3.3 V 上拉接 RX Tach GPIO；
- 风扇电源和接收机必须共地；
- 不允许把 MCU GPIO 直接推挽接到可能被上拉至 5 V 的风扇 PWM 控制脚；
- 不允许在未测量电压时把 Tach 直接接 MCU。

## 3. 建议控制级

逻辑模型：

```text
ESP GPIO ── gate/base resistor ── N-MOS/NPN
                                  │
Fan Pin 4 PWM ─────────────────── drain/collector
                                  │
GND ───────────────────────────── source/emitter
```

设计要求：

- MCU 低电平或高阻时晶体管关闭；
- 晶体管关闭时风扇 PWM 脚被风扇内部上拉，代表全速；
- 固件因此把逻辑 duty 反相后写入 GPIO 波形；
- 建议给 gate/base 加明确下拉；
- 选择在 25 kHz 下有足够开关速度的器件。

`Esp8266FanOutput` 默认 `gate_active_high=true`：

```text
逻辑 duty=255（全速） -> GPIO duty=0 -> 晶体管关断
逻辑 duty=0（请求停转） -> GPIO duty=255 -> 晶体管导通
```

## 4. Tach 输入

推荐：

```text
3.3 V ── 4.7k~10k ──┬── ESP Tach GPIO
                     │
Fan Pin 3 Tach ──────┘
GND 共地
```

必须先验证风扇或其他设备没有把该线拉到 5 V/12 V。必要时使用分压、缓冲器、光耦或电平转换。

默认按每转 2 个脉冲计算。代码用下降沿周期计算，不在 ISR 中做除法或无线发送。

## 5. GPIO1 / GPIO3 的特殊风险

GPIO1/3 原本是 UART TX/RX：

- RX 固件不启用 Serial；
- 启动 ROM 仍可能在 GPIO1 输出启动信息；
- 外部晶体管级必须让这种瞬态不造成危险停转；
- 烧写时 USB-UART 与风扇接口可能争用，需要跳线、串联电阻或可断开连接；
- 不同板型可能在这两个 GPIO 上已有电阻、反相器或外围器件。

## 6. 射频前端核对表

为每一个实际板型填写：

```text
板名/PCB版本：
原 ELRS target：
MCU：
Radio：
NSS：
DIO1：
RST：
BUSY：
SCK/MISO/MOSI：
RXEN：
TXEN：
PA enable：
LNA enable：
天线开关真值表：
最大安全 TX power：
供电电压：
可用 PWM GPIO：
可用 Tach GPIO：
```

板上存在 PA/LNA 时，不能只依赖 SX1280 内部功率值；必须正确控制射频前端，否则可能完全收不到、无法发射或损坏器件。

## 7. 首次通电顺序

1. 不接风扇，只验证 3.3 V 电源和 MCU 启动。
2. 不接 PA 高功率，先用最小射频功率和近距离衰减条件验证收发。
3. 用逻辑分析仪验证 poll/sequence，再接 PWM 晶体管级。
4. 用示波器和假负载验证 25 kHz。
5. 测量风扇 Pin 3/4 静态电压。
6. 接一只风扇，验证拔 TX、拔串口、复位 RX 均回全速。
7. 再加入第二节点，最后扩到 16 节点。
