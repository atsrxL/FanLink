#include "fanlink/platform/esp8266/radiolib_sx1280_port.hpp"

#include <Arduino.h>

namespace fanlink::platform::esp8266 {

RadioLibSx1280Port::RadioLibSx1280Port(Sx1280PortConfig config)
    : config_(config),
      spiSettings_(config.spiHz, MSBFIRST, SPI_MODE0),
      module_(config.nssPin, config.dio1Pin, config.resetPin, config.busyPin, SPI, spiSettings_),
      radio_(&module_) {}

std::array<std::uint8_t, 4> RadioLibSx1280Port::makeSyncWord(std::uint32_t networkId) {
  // Deterministic mixing; this is a network discriminator, not cryptography.
  networkId ^= 0xA53C9E17UL;
  networkId ^= networkId >> 16U;
  networkId *= 0x7FEB352DUL;
  networkId ^= networkId >> 15U;
  std::array<std::uint8_t, 4> sync{
      static_cast<std::uint8_t>(networkId & 0xFFU),
      static_cast<std::uint8_t>((networkId >> 8U) & 0xFFU),
      static_cast<std::uint8_t>((networkId >> 16U) & 0xFFU),
      static_cast<std::uint8_t>((networkId >> 24U) & 0xFFU),
  };
  // Avoid the all-zero pattern.
  if ((sync[0] | sync[1] | sync[2] | sync[3]) == 0U) {
    sync = {0xF1U, 0xA5U, 0x5AU, 0x1FU};
  }
  return sync;
}

RadioResult RadioLibSx1280Port::mapResult(int state) {
  if (state == RADIOLIB_ERR_NONE) {
    return RadioResult::Ok;
  }
  if (state == RADIOLIB_ERR_RX_TIMEOUT) {
    return RadioResult::Timeout;
  }
  if (state == RADIOLIB_ERR_CRC_MISMATCH) {
    return RadioResult::CrcError;
  }
  return RadioResult::IoError;
}

std::int8_t RadioLibSx1280Port::clampRssi(float rssi) {
  if (rssi < -127.0F) {
    return -127;
  }
  if (rssi > 0.0F) {
    return 0;
  }
  return static_cast<std::int8_t>(rssi);
}

bool RadioLibSx1280Port::begin(std::uint32_t networkId) {
  SPI.begin();

  if (config_.rxEnablePin >= 0 && config_.txEnablePin >= 0) {
    radio_.setRfSwitchPins(static_cast<std::uint32_t>(config_.rxEnablePin),
                           static_cast<std::uint32_t>(config_.txEnablePin));
  }

  // The non-struct overload remains in RadioLib 7.7.1 and is intentionally used
  // here to keep the starter readable. Codex may migrate to ConfigFLRC_t after
  // the first verified build without changing the public radio-port contract.
  lastError_ = radio_.beginFLRC(config_.frequencyMhz,
                                static_cast<std::uint16_t>(config_.bitRateKbps),
                                config_.codingRate, config_.outputPowerDbm,
                                config_.preambleBits, RADIOLIB_SHAPING_0_5);
  if (lastError_ != RADIOLIB_ERR_NONE) {
    return false;
  }

  auto syncWord = makeSyncWord(networkId);
  lastError_ = radio_.setSyncWord(syncWord.data(), syncWord.size());
  if (lastError_ != RADIOLIB_ERR_NONE) {
    return false;
  }

  lastError_ = radio_.setCRC(2U, 0x1D0FU, 0x1021U);
  initialized_ = lastError_ == RADIOLIB_ERR_NONE;
  return initialized_;
}

RadioResult RadioLibSx1280Port::transmit(const std::uint8_t* data, std::size_t length) {
  if (!initialized_ || data == nullptr || length == 0U) {
    lastError_ = RADIOLIB_ERR_INVALID_PACKET_LENGTH;
    return RadioResult::IoError;
  }
  lastError_ = radio_.transmit(data, length);
  return mapResult(lastError_);
}

RadioRxResult RadioLibSx1280Port::receive(std::uint8_t* data, std::size_t capacity,
                                         std::uint32_t timeoutMs) {
  if (!initialized_ || data == nullptr || capacity == 0U) {
    lastError_ = RADIOLIB_ERR_INVALID_PACKET_LENGTH;
    return RadioRxResult{RadioResult::IoError, 0U, -127, lastError_};
  }

  // Both FanLink air packet types are fixed at kAirPacketSize bytes. Therefore
  // this adapter can pass the caller's exact capacity as the known packet
  // length and report that same length on success.
  // SX128x's blocking receive overload documents timeout in microseconds.
  const auto timeoutUs = static_cast<RadioLibTime_t>(timeoutMs) * 1000U;
  lastError_ = radio_.receive(data, capacity, timeoutUs);
  const auto result = mapResult(lastError_);
  if (result != RadioResult::Ok) {
    return RadioRxResult{result, 0U, -127, lastError_};
  }

  return RadioRxResult{RadioResult::Ok, capacity, clampRssi(radio_.getRSSI()), lastError_};
}

}  // namespace fanlink::platform::esp8266
