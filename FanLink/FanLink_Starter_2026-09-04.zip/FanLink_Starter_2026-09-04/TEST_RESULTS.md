# FanLink validation results

Generated: 2026-09-04

## Toolchain
```text
g++ (Debian 14.2.0-19) 14.2.0
cmake version 3.31.6
Python 3.13.5
PlatformIO CLI: unavailable in this generation environment
```

## Native C++ tests
```text
PASS: 143 checks
```

## Python Host protocol self-test
```text
PASS: fanlink_cli self-test
```

## Python syntax compilation
```text
PASS: python3 -m py_compile tools/*.py
```

## Firmware source syntax smoke
```text
PASS: firmware syntax smoke (stub APIs only)
```

This uses repository API stubs only. It is not a real ESP8266/RadioLib build.

## CMake / CTest
```text
-- The CXX compiler identification is GNU 14.2.0
-- Detecting CXX compiler ABI info
-- Detecting CXX compiler ABI info - done
-- Check for working CXX compiler: /usr/bin/c++ - skipped
-- Detecting CXX compile features
-- Detecting CXX compile features - done
-- Configuring done (0.8s)
-- Generating done (0.0s)
-- Build files have been written to: /mnt/data/FanLink_Starter_2026-09-04/build/final-cmake
[ 12%] Building CXX object CMakeFiles/fanlink_core.dir/src/common/crc16.cpp.o
[ 25%] Building CXX object CMakeFiles/fanlink_core.dir/src/common/protocol.cpp.o
[ 37%] Building CXX object CMakeFiles/fanlink_core.dir/src/common/serial_protocol.cpp.o
[ 50%] Building CXX object CMakeFiles/fanlink_core.dir/src/app/rx_controller.cpp.o
[ 62%] Building CXX object CMakeFiles/fanlink_core.dir/src/app/tx_controller.cpp.o
[ 75%] Linking CXX static library libfanlink_core.a
[ 75%] Built target fanlink_core
[ 87%] Building CXX object CMakeFiles/fanlink_native_tests.dir/tests/native_tests.cpp.o
[100%] Linking CXX executable fanlink_native_tests
[100%] Built target fanlink_native_tests
Internal ctest changing into directory: /mnt/data/FanLink_Starter_2026-09-04/build/final-cmake
Test project /mnt/data/FanLink_Starter_2026-09-04/build/final-cmake
    Start 1: fanlink_native_tests
1/1 Test #1: fanlink_native_tests .............   Passed    0.01 sec

100% tests passed, 0 tests failed out of 1

Total Test time (real) =   0.02 sec
```

## Poll simulation
```text
slots=100 slot_rate_hz=100.000
full_sweep_ms=160.000
node=01 polls=7 replies=7
node=02 polls=7 replies=7
node=03 polls=7 replies=7
node=04 polls=7 replies=7
node=05 polls=6 replies=6
node=06 polls=6 replies=6
node=07 polls=6 replies=6
node=08 polls=6 replies=6
node=09 polls=6 replies=6
node=10 polls=6 replies=6
node=11 polls=6 replies=6
node=12 polls=6 replies=6
node=13 polls=6 replies=6
node=14 polls=6 replies=6
node=15 polls=6 replies=6
node=16 polls=6 replies=6
```

## Not validated

- Real PlatformIO dependency resolution and link
- Any ESP8285/SX1280 commercial board
- RF pin map, TCXO, PA/LNA or antenna switch
- 25 kHz waveform on an oscilloscope
- Tach voltage or RPM accuracy
- RF airtime, turnaround, packet loss or endurance
