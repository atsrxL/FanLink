# Upstream references for the next engineer

External source code is not bundled in this package. Verify the exact revision used by the final build.

## RadioLib

- Repository: https://github.com/jgromes/RadioLib
- SX128x API header: https://github.com/jgromes/RadioLib/blob/master/src/modules/SX128x/SX128x.h
- SX1280 class: https://github.com/jgromes/RadioLib/tree/master/src/modules/SX128x
- Intended dependency in this starter: 7.7.1

Check FLRC configuration, sync word, CRC, fixed-length receive, timeout units, RF-switch control and RSSI behavior against the resolved source.

## ESP8266 Arduino Core

- Repository: https://github.com/esp8266/Arduino
- PWM/waveform implementation: https://github.com/esp8266/Arduino/blob/master/cores/esp8266/core_esp8266_waveform_pwm.cpp
- Waveform declarations: https://github.com/esp8266/Arduino/blob/master/cores/esp8266/core_esp8266_waveform.h

Confirm 25 kHz behavior, static endpoints, interrupt interaction, GPIO1 boot behavior and the core version resolved by PlatformIO.

## PlatformIO Espressif 8266

- Platform: https://github.com/platformio/platform-espressif8266
- Intended baseline: `espressif8266@4.2.1`

## ExpressLRS hardware references

No ExpressLRS source is included. The exact commercial board target/hardware definition may still be the best source for pin and RF-front-end mapping:

- Repository: https://github.com/ExpressLRS/ExpressLRS
- Hardware targets: inspect the target matching the exact product and PCB revision.

Importing ExpressLRS code would introduce GPL-3.0 obligations and must not be done casually. Pin mapping facts may be reimplemented without copying application code, but document their source.

## Four-wire fan interface

Use the actual fan datasheet or authoritative four-wire PWM fan specification for electrical limits, nominal 25 kHz control and Tach behavior. Do not assume all fan variants stop at 0% or expose the same internal pull-up.
