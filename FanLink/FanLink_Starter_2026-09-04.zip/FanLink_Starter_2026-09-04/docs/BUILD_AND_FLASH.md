# Build and flash guide

## 1. Desktop verification

Run before and after common/controller changes:

```bash
./scripts/run_native_tests.sh
python3 tools/fanlink_cli.py --self-test
python3 -m py_compile tools/*.py
./tools/run_firmware_syntax_smoke.sh
```

Optional CMake path:

```bash
cmake -S . -B build/cmake -DCMAKE_BUILD_TYPE=Debug
cmake --build build/cmake --parallel
ctest --test-dir build/cmake --output-on-failure
```

The syntax smoke uses repository stubs. It does not download or compile the actual Arduino Core or RadioLib.

## 2. Real PlatformIO build

Install PlatformIO in an environment with dependency access, then run:

```bash
pio run -e fanlink_tx_esp8285
pio run -e fanlink_rx_node01
pio run -e fanlink_rx_node16
```

Build all labelled images:

```bash
python3 tools/build_firmware.py --tx --all-rx
```

Outputs are copied to `dist/` with SHA-256 files when builds succeed.

## 3. Pinned baseline

`platformio.ini` declares:

```text
platform = espressif8266@4.2.1
board = esp8285
framework = arduino
RadioLib = 7.7.1
C++ = gnu++17
```

Do not silently upgrade dependencies during initial takeover. First reproduce or fix the pinned build; then record any upgrade and reason in `CHANGELOG.md` and an ADR.

## 4. Configuration overrides

Defaults live in `include/fanlink/build_config.hpp`. PlatformIO build flags may override macros, for example:

```ini
-DFANLINK_NETWORK_ID=0x12345678UL
-DFANLINK_RADIO_FREQUENCY_MHZ=2405.0F
-DFANLINK_RADIO_OUTPUT_POWER_DBM=-10
-DFANLINK_RADIO_NSS_PIN=...
-DFANLINK_RADIO_DIO1_PIN=...
-DFANLINK_RADIO_RST_PIN=...
-DFANLINK_RADIO_BUSY_PIN=...
-DFANLINK_RADIO_RXEN_PIN=...
-DFANLINK_RADIO_TXEN_PIN=...
-DFANLINK_FAN_PWM_PIN=1
-DFANLINK_TACH_PIN=3
```

The generic defaults are not a supported commercial board target.

## 5. Before first flash

Record all of the following:

- exact board and PCB revision;
- original target/schematic source;
- boot strap pins and flash mode;
- serial recovery wiring;
- SPI/DIO/BUSY/RESET mapping;
- TCXO and RF-front-end state table;
- safe minimum transmit power;
- whether GPIO1/GPIO3 are disconnected from the programmer during normal use;
- external fan PWM and Tach protection circuit.

## 6. First-flash sequence

1. Flash without a fan connected.
2. Confirm the MCU can be recovered and reflashed.
3. Confirm power rails and idle RF-front-end states.
4. Bring up SX1280 at minimum safe power.
5. Test one-way Control packets before allowing RX transmission.
6. Attach debug/logic analyzer signals.
7. Add the open-drain PWM stage and scope it with a safe load.
8. Only after voltage checks, connect Tach and a fan.

Do not generate or distribute “final” `.bin` files until the exact board target and failure tests are documented.
