#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PARENT="$(dirname "$ROOT")"
NAME="$(basename "$ROOT")"
OUTPUT="$PARENT/${NAME}.zip"

rm -f "$OUTPUT"
(
  cd "$PARENT"
  zip -qr "$OUTPUT" "$NAME" \
    -x "$NAME/.pio/*" "$NAME/build/*" "$NAME/__pycache__/*" "$NAME/*.pyc"
)
sha256sum "$OUTPUT" > "$OUTPUT.sha256"
printf 'Created %s\n' "$OUTPUT"
cat "$OUTPUT.sha256"
