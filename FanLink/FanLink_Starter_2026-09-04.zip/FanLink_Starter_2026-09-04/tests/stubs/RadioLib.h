#pragma once

#include <cstddef>
#include <cstdint>

#include "SPI.h"

using RadioLibTime_t = std::uint32_t;

#define RADIOLIB_ERR_NONE 0
#define RADIOLIB_ERR_RX_TIMEOUT (-6)
#define RADIOLIB_ERR_CRC_MISMATCH (-7)
#define RADIOLIB_ERR_INVALID_PACKET_LENGTH (-8)
#define RADIOLIB_SHAPING_0_5 1

class Module {
 public:
  Module(int, int, int, int, SPIClass&, SPISettings) {}
};

class SX1280 {
 public:
  explicit SX1280(Module*) {}
  void setRfSwitchPins(std::uint32_t, std::uint32_t) {}
  std::int16_t beginFLRC(float, std::uint16_t, std::uint8_t, std::int8_t,
                         std::uint16_t, std::uint8_t) {
    return RADIOLIB_ERR_NONE;
  }
  std::int16_t setSyncWord(std::uint8_t*, std::size_t) { return RADIOLIB_ERR_NONE; }
  std::int16_t setCRC(std::uint8_t, std::uint32_t, std::uint16_t) {
    return RADIOLIB_ERR_NONE;
  }
  std::int16_t transmit(const std::uint8_t*, std::size_t) { return RADIOLIB_ERR_NONE; }
  std::int16_t receive(std::uint8_t*, std::size_t, RadioLibTime_t) {
    return RADIOLIB_ERR_NONE;
  }
  std::size_t getPacketLength(bool = true) { return 0U; }
  float getRSSI() { return -50.0F; }
};
