# Changelog

## 0.1.0 — 2026-09-04

Initial Codex hand-off starter:

- Created a standalone FanLink application rather than an ExpressLRS fork.
- Added fixed 30-byte Control and 30-byte RPM Reply packets.
- Added CRC-16/CCITT-FALSE and fixed-length binary host serial protocol.
- Added full-state 16-channel downlink and strict poll 1–16 scheduling.
- Added TX host watchdog and RX link watchdog, both failing to full speed.
- Added RX stale-sequence rejection, same-sequence retry support, gap accounting and 16-bit wrap handling.
- Added platform-independent TX/RX controllers and 143 native checks.
- Added ESP8266/ESP8285 fan PWM, Tach and RadioLib SX1280 starter adapters.
- Added PlatformIO environments for TX and RX nodes 01–16.
- Added Python CLI, cluster simulation, build collector, syntax smoke test and hand-off documentation.
- Pinned intended embedded dependencies to `espressif8266@4.2.1` and RadioLib `7.7.1`.
- Set the generic SX1280 chip-power default to `-18 dBm` as a cautious bring-up starting point.
- No embedded dependency build or hardware validation is claimed.
