# FanLink task backlog

## P0 — software baseline

- [x] Define fixed 30-byte Control and RPM packets with application CRC.
- [x] Implement full-state 16-channel TX scheduler and poll 1–16.
- [x] Implement single-channel RX selection and poll-gated reply.
- [x] Implement host and RF fail-safe-to-full-speed behavior.
- [x] Implement stale sequence rejection, retry, gap and wrap behavior.
- [x] Add desktop-testable interfaces/controllers.
- [x] Add binary Host protocol and Python CLI.
- [x] Add native tests and Arduino/RadioLib stub syntax smoke.
- [x] Add PlatformIO environments for TX and RX 01–16.
- [ ] Run clean PlatformIO TX build with real dependencies.
- [ ] Run clean PlatformIO RX Node 01 and Node 16 builds.
- [ ] Resolve real RadioLib 7.7.1 API/compiler differences without changing wire format.
- [ ] Add PlatformIO CI after the first successful real build.

## P0 — exact hardware target

- [ ] Identify TX product, PCB revision and original ELRS target.
- [ ] Identify RX product, PCB revision and original ELRS target.
- [ ] Verify MCU, flash, oscillator and SX1280/SX1281 variant.
- [ ] Verify NSS, DIO1, RESET, BUSY, SCK, MISO and MOSI.
- [ ] Verify TCXO enable/frequency if present.
- [ ] Implement and verify PA/LNA/antenna-switch state table.
- [ ] Determine minimum and maximum safe RF output settings.
- [ ] Verify GPIO1/GPIO3 pads and all attached components.
- [ ] Document recovery flashing/unbrick procedure.
- [ ] Split generic build configuration into exact TX and RX board targets.

## P0 — single-node bench bring-up

- [ ] Initialize SX1280 at minimum safe power.
- [ ] Prove one-way 30-byte Control reception before enabling RX transmit.
- [ ] Prove network ID, sequence and own-channel selection on a debug pin/log.
- [ ] Build the external open-drain PWM interface.
- [ ] Scope 25 kHz at duty 0/1/64/128/192/254/255.
- [ ] Measure GPIO1 boot waveform and verify hardware-default full speed.
- [ ] Measure fan Pin 3 Tach high voltage before MCU connection.
- [ ] Verify RPM against an independent reading.
- [ ] Enable one polled Reply and measure turnaround/airtime.
- [ ] Tune reply delay, receive timeout and slot period from measurements.
- [ ] Test host timeout, TX loss, RX reset, corrupt packet and wrong network ID.
- [ ] Run one TX + one RX continuously for at least 30 minutes, then 8 hours.

## P0 — multiple nodes

- [ ] Bring up two uniquely labelled node IDs.
- [ ] Confirm an unpolled node never transmits.
- [ ] Confirm a missing node cannot block later slots.
- [ ] Bring up at least four nodes and check channel isolation.
- [ ] Deliberately duplicate a node ID and document collision symptoms.
- [ ] Validate complete 1–16 logic with hardware or an RF test fixture.

## P1 — reliability after measured baseline

- [ ] Add counters for malformed packets, stale sequence rejects and RF errors.
- [ ] Add parser/property fuzz tests.
- [ ] Determine whether blocking RadioLib calls satisfy the measured 10 ms slot.
- [ ] Replace only the radio adapter with an asynchronous DIO1 state machine if measurements require it.
- [ ] Quantify packet error rate, jitter and telemetry freshness.
- [ ] Add watchdog/brownout tests.
- [ ] Design rendezvous + FHSS as a separate protocol milestone.
- [ ] Complete regional RF compliance review.

## P2 — optional after stable hardware

- [ ] Compile-time metadata/status query.
- [ ] Persistent node provisioning, only if 16 labelled binaries are operationally unacceptable.
- [ ] Optional CRSF Host Adapter that leaves the FanLink air protocol unchanged.
- [ ] Host dashboard.
- [ ] Firmware update strategy.

Do not move P2 work ahead of unresolved P0 safety or hardware items.
