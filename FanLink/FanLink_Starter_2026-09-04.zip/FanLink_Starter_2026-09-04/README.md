# FanLink Starter 0.1

FanLink 是一套面向 **1 个发射端（TX）+ 最多 16 个单风扇接收节点（RX）** 的极简无线控制固件骨架。

每个 10 ms 时隙中，TX 广播全部 16 路占空比并指定一个 `poll_id`；节点 X 只应用 `duty[X-1]`，只有 `poll_id == X` 时才回传 RPM。项目不包含 ExpressLRS 应用层，也不兼容标准 ELRS OTA、绑定或遥测。

> **当前状态：基础源码与桌面测试已完成；没有在任何实际 ELRS 板卡上编译、刷写或射频验证。默认 ESP8285/SX1280 引脚只是示例，烧写前必须按准确板型核对。**

## 1. 已包含的功能

| 功能 | 状态 |
|---|---|
| 16 路完整状态广播 | 已实现 |
| `poll_id` 1→16 循环 | 已实现 |
| 30 字节固定 Control 包 | 已实现并测试 |
| 30 字节固定 RPM Reply 包 | 已实现并测试 |
| CRC-16/CCITT-FALSE | 已实现并测试 |
| 16 位序号、旧包拒绝、重复包重试、回绕 | 已实现并测试 |
| TX 上位机 watchdog → 全速 | 已实现 |
| RX 无线链路 watchdog → 全速 | 已实现 |
| ESP8266/ESP8285 25 kHz PWM 适配 | 已实现，待示波器验证 |
| Tach 下降沿周期采集与 RPM 计算 | 已实现，待电气与实机验证 |
| RadioLib SX1280 FLRC 固定频点适配 | 已实现，待真实依赖编译和硬件验证 |
| 二进制上位机协议与 Python CLI | 已实现并自测 |
| FHSS、绑定、动态功率、WebUI、OTA | 明确不在 v0.1 中 |

## 2. 数据路径

```text
电脑 / 终端
  │ FanLink 二进制串口协议，115200 8N1
  ▼
FanLink TX
  │ 每 10 ms：network_id + sequence + poll_id + duty[16]
  ▼
RX 1 ... RX 16
  │ 每个节点只取自己的 duty
  │ 只允许被 poll 的节点发 RPM Reply
  ▼
FanLink TX 聚合 16 个节点状态并回传给上位机
```

默认 10 ms 时隙对应：

- 控制广播 100 Hz；
- 16 个节点一轮约 160 ms；
- 每节点理论轮询频率约 6.25 Hz。

这些只是 bring-up 参数，必须在真实射频模块上测量空中时长、BUSY/DIO1、RF 前端切换和收发 turnaround 后再冻结。

## 3. 仓库结构

```text
.
├── AGENTS.md                         # Codex 仓库级工作规则
├── REQUIREMENTS.md                   # 冻结需求与验收标准
├── COMMUNICATION_REQUIREMENTS.md     # Codex 汇报和交付规则
├── HANDOFF_TO_CODEX.md               # 当前状态、风险与接手步骤
├── HANDOFF_STATUS.md/.json           # 机器/人工可读交接状态
├── PROTOCOL.md                       # 空口与上位机协议唯一规范
├── HARDWARE.md                       # 风扇接线、GPIO、RF 前端风险
├── SAFETY.md                         # 失效保护原则
├── TASKS.md                          # P0/P1/P2 工作清单
├── codex_prompt.txt                  # 可直接粘贴给 Codex 的提示词
├── include/fanlink/                  # 无 Arduino 依赖的公共接口与协议
├── src/common/                       # CRC、空口、串口编码/解码
├── src/app/                          # TX/RX 可测试状态机
├── src/main_tx.cpp                   # Arduino TX 入口
├── src/main_rx.cpp                   # Arduino RX 入口
├── lib/fanlink_platform_esp8266/     # ESP8266 PWM/Tach/RadioLib 适配层
├── tests/                            # 原生测试与 Arduino API stub
├── tools/                            # Python CLI、构建和仿真工具
└── docs/                             # 架构、构建、无线移植和测试计划
```

## 4. 接手后的第一组命令

```bash
./scripts/run_native_tests.sh
python3 tools/fanlink_cli.py --self-test
python3 -m py_compile tools/*.py
./tools/run_firmware_syntax_smoke.sh
```

本包生成时结果：

```text
native C++ tests                    PASS: 143 checks
Python host protocol self-test      PASS
Python syntax compile               PASS
Arduino/RadioLib stub syntax smoke  PASS
CMake + CTest                       PASS: 1/1
```

完整交付时测试记录见 [`TEST_RESULTS.md`](TEST_RESULTS.md)。

`run_firmware_syntax_smoke.sh` 只检查本仓库代码在小型 API stub 下的语法闭合，**不能替代 PlatformIO 真实依赖编译，更不能替代硬件测试**。

## 5. PlatformIO 构建入口

依赖在 `platformio.ini` 中固定为：

- PlatformIO `espressif8266@4.2.1`；
- RadioLib `7.7.1`；
- C++17。

TX：

```bash
pio run -e fanlink_tx_esp8285
```

RX 节点 1、16：

```bash
pio run -e fanlink_rx_node01
pio run -e fanlink_rx_node16
```

构建 TX 和全部 RX，并收集 `.bin`：

```bash
python3 tools/build_firmware.py --tx --all-rx
```

本包环境没有可用的 PlatformIO 依赖缓存且无法联网，因此上述嵌入式构建命令尚未在交付环境执行成功；这是 Codex 接手后的第一个软件 P0。

## 6. 硬件配置入口

默认宏在：

```text
include/fanlink/build_config.hpp
```

关键项：

```text
FANLINK_NETWORK_ID
FANLINK_NODE_ID
FANLINK_RADIO_NSS_PIN
FANLINK_RADIO_DIO1_PIN
FANLINK_RADIO_RST_PIN
FANLINK_RADIO_BUSY_PIN
FANLINK_RADIO_RXEN_PIN
FANLINK_RADIO_TXEN_PIN
FANLINK_RADIO_FREQUENCY_MHZ
FANLINK_RADIO_OUTPUT_POWER_DBM
FANLINK_FAN_PWM_PIN
FANLINK_TACH_PIN
FANLINK_GATE_ACTIVE_HIGH
```

默认示例假设 ESP8285 + SX1280，且 RX 使用 GPIO1（原 UART TX）作风扇控制逻辑输出、GPIO3（原 UART RX）作 Tach 输入。它们不是任意 ELRS 接收机的通用引脚。PA、LNA、天线开关、TCXO 和板载反相器也可能需要独立适配。

## 7. 风扇接口必须按四线标准接法理解

标准四线 PC 风扇通常为：

| 风扇针脚 | 功能 |
|---:|---|
| 1 | GND |
| 2 | +12 V |
| 3 | Tach / Sense 输出 |
| 4 | PWM Control 输入 |

因此：

- RX 的 PWM GPIO 必须经外部 N-MOS/NPN 开漏级连接风扇 Pin 4；
- 风扇 Pin 3 Tach 经确认安全的 3.3 V 上拉/电平保护后进入 RX Tach GPIO；
- 不能把 3.3 V GPIO 直接推挽到风扇 PWM 线；
- MCU 复位或掉电时，外部电路应让晶体管关闭、PWM 线释放，风扇趋向全速。

完整接线和风险见 [`HARDWARE.md`](HARDWARE.md) 与 [`SAFETY.md`](SAFETY.md)。

## 8. 上位机快速使用

安装 CLI 依赖：

```bash
python3 -m pip install -r tools/requirements.txt
```

持续维持全部节点 180/255 的占空比并监看状态：

```bash
python3 tools/fanlink_cli.py --port /dev/ttyUSB0 hold --all 180
```

持续发送 16 个值：

```bash
python3 tools/fanlink_cli.py --port /dev/ttyUSB0 hold --values \
  255 240 224 208 192 176 160 144 128 112 96 80 64 48 32 16
```

单次 `set`/`full` 命令只发一帧；默认 500 ms 后 TX watchdog 会回到全部全速。正常运行应使用 `hold` 或由上位机周期发送 `SET_ALL_DUTY`/`HEARTBEAT`。

## 9. 明确不做的事情

v0.1 不包含：

- 标准 ELRS 空口兼容；
- 完整 CRSF、MSP、Lua、Wi-Fi、WebUI；
- 动态节点发现、自动地址分配；
- FHSS、动态功率、速率扫描；
- 通用舵机/传感器/遥测框架；
- OTA 升级或加密认证。

这些功能不得在没有测量依据和用户明确需求时重新引入。

## 10. Codex 阅读顺序

1. `AGENTS.md`
2. `REQUIREMENTS.md`
3. `COMMUNICATION_REQUIREMENTS.md`
4. `HANDOFF_TO_CODEX.md`
5. `PROTOCOL.md`
6. `HARDWARE.md`
7. `TASKS.md`
8. `codex_prompt.txt`

## 11. 许可证

本仓库自有源码使用 MIT License。RadioLib 和 ESP8266 Arduino Core 作为外部依赖，不在压缩包中；详见 `THIRD_PARTY_NOTICES.md`。本包没有复制 ExpressLRS 源码。
